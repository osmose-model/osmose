package fr.ird.osmose.util.version;

import java.util.Calendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nbarrier
 */
public class Version3Update3Release2 extends AbstractVersion {

    public Version3Update3Release2() {
        super(3, 3, 2, 2018, Calendar.NOVEMBER, 28);
    }

    @Override
    void updateParameters() {
        // Nothing to be done for this version
    }
    
}
